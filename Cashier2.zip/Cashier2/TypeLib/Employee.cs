﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TypeLib
{
    public class Employee
    {
        public int ID { get; set; }
        public string Username { get; set; }
        public int Password { get; set; }
        public int Role { get; set; }
    }
}
