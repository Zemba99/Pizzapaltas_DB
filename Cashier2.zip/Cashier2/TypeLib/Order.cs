﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TypeLib
{
    public class Order
    {
        public int ID { get; set; }
        public int Order_status { get; set; }
    }
}
