﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TypeLib
{
    public enum eBackend
    {
        MsSQL = 0,
        Postgre = 1
    }
}
