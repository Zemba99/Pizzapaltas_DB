﻿using System;
using TypeLib;


namespace Cashier
{
    class Program
    {

        
        static void Main(string[] args)
        {

            Consoldel.ShowWindow();
        }
    }
}
