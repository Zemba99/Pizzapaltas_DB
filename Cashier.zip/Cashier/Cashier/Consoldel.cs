﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Data;



namespace Cashier
{
    class Consoldel
    {


        public static void ShowWindow()
        {
            // vad som ska hämtas från datorbasen
            string val = "SELECT * FROM dbo.Orders WHERE Order_status = 1";
            int number = 0;
            
            int poss = 0;
            Databas a = new Databas();

            
            // för att loopen alltid ska var igång
            bool alltid = true;
            

            // loop så att consolen ska kunna uppdateras
            while (alltid)
            {

                

                try
                {
                    a.OpenConection();
                    SqlDataReader dr = a.DataReader(val);

                    


                    Console.WriteLine("\tOrdar som ska hämtas: \n");
                    while (dr.Read())
                    {

                        

                        if (number == poss)
                        {
                            Console.ForegroundColor = ConsoleColor.Black;
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.WriteLine(dr["ID"].ToString());
                            
                            
                        }



                        //else turn back to normal
                        else
                        {
                            Console.BackgroundColor = ConsoleColor.Black;
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.WriteLine(dr["ID"].ToString());
                            

                        }
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.ForegroundColor = ConsoleColor.White;
                        number++;
                    }
                    Console.WriteLine("\n\nFör att ta bort order, klicka på Enter\nFör att navigera, använd piltangenterna eller W och S\nFör att uppdatera sidan, använd navigerinsknapparna");
                    a.CloseConnection();
                    dr.Close();
        

                }
                catch { Console.WriteLine("error"); }
                    
                
                // movements and delete function
                finally
                {
                    a.OpenConection();
                    SqlDataReader dr = a.DataReader(val);
                    ConsoleKeyInfo key = Console.ReadKey();
                    if (key.Key == ConsoleKey.DownArrow || key.KeyChar == 's')
                    {
                        // poss gouse down one position in the text
                        poss += 1;

                        //clear the window
                        Console.Clear();
                        //reset the number on orders
                        number = 0;

                    }
                    // same as down but oppisit way
                    if (key.Key == ConsoleKey.UpArrow || key.KeyChar == 'w')

                    {
                        poss -= 1;
                        Console.Clear();
                        number = 0;

                    }
                    // if u press enter
                    if (key.Key == ConsoleKey.Enter)
                    {
                        
                        // clear window
                        Console.Clear();

                        
                      var antal = new List<string>();
                            
                           
                       while (dr.Read())
                       {
                         antal.Add(dr["ID"].ToString());
                       }
                       dr.Close();

                       try
                       {
                         a.ExecuteQueries($"DELETE FROM dbo.Orders WHERE ID={antal.ElementAt(poss)}");
                       //  antal.Remove(antal.ElementAt(poss));
                       }
                       catch { Console.WriteLine("could not delete"+antal[poss]); }

                       number = 0;
                    }

                    else 
                    {
                    Thread.Sleep(5000);

                        Console.Clear();
                        number = 0;

                    }
                    a.OpenConection();

                    int test = a.Tester() - 1;
                    //look if u go over or under the posible value go to lowest numberor highest
                    if (poss > test)
                    {
                        poss = 0;
                    }
                    if (poss < 0)
                    {
                        poss = test;
                    }
                    a.CloseConnection();
                
                    
                }
                

            }
        }

        private static void ATimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
                        

                                   
                        

                                


                               
                               
                        
                        
                            
                            
                            
                             
                        
                        
                        


                   








