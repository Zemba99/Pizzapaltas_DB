﻿using System;

namespace Cashier
{
    class Program
    {
        static void Main(string[] args)
        {

            Consoldel.ShowWindow();
        }
    }
}
